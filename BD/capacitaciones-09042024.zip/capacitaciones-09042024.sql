-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.30 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para app_capacitaciones
DROP DATABASE IF EXISTS `app_capacitaciones`;
CREATE DATABASE IF NOT EXISTS `app_capacitaciones` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `app_capacitaciones`;

-- Volcando estructura para tabla app_capacitaciones.empresas
DROP TABLE IF EXISTS `empresas`;
CREATE TABLE IF NOT EXISTS `empresas` (
  `nit` int NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `departamento` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `municipio_ciudad` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`nit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.empresas: ~2 rows (aproximadamente)
DELETE FROM `empresas`;
INSERT INTO `empresas` (`nit`, `nombre`, `departamento`, `municipio_ciudad`) VALUES
	(123456789, 'Empresa ABC', 'Departamento 1', 'Ciudad A'),
	(987654321, 'Empresa XYZ', 'Departamento 2', 'Ciudad B');

-- Volcando estructura para tabla app_capacitaciones.estudiantes
DROP TABLE IF EXISTS `estudiantes`;
CREATE TABLE IF NOT EXISTS `estudiantes` (
  `id_estudiante` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `apellido` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_empresa` int DEFAULT NULL,
  PRIMARY KEY (`id_estudiante`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `estudiantes_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `empresas` (`nit`)
) ENGINE=InnoDB AUTO_INCREMENT=1129580585 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.estudiantes: ~3 rows (aproximadamente)
DELETE FROM `estudiantes`;
INSERT INTO `estudiantes` (`id_estudiante`, `nombre`, `apellido`, `id_empresa`) VALUES
	(1, 'Juan', 'Perez', 123456789),
	(2, 'María', 'López', 987654321),
	(1129580584, 'Donna', 'Lopez', 123456789);

-- Volcando estructura para tabla app_capacitaciones.examenes
DROP TABLE IF EXISTS `examenes`;
CREATE TABLE IF NOT EXISTS `examenes` (
  `id_examen` int NOT NULL AUTO_INCREMENT,
  `nombre_examen` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `descripcion` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `id_modulo` int DEFAULT NULL,
  `tipo_examen` enum('antes','despues') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fecha_vigencia` date DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_examen`),
  KEY `id_modulo` (`id_modulo`),
  CONSTRAINT `examenes_ibfk_1` FOREIGN KEY (`id_modulo`) REFERENCES `modulos` (`id_modulo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.examenes: ~4 rows (aproximadamente)
DELETE FROM `examenes`;
INSERT INTO `examenes` (`id_examen`, `nombre_examen`, `descripcion`, `id_modulo`, `tipo_examen`, `fecha_vigencia`, `activo`) VALUES
	(1, 'TRABAJO EN CONFINADO', 'EVALUACIÓN DE CONOCIMIENTOS PREVIOS', 1, 'antes', '2025-01-01', 1),
	(2, 'TRABAJO EN CONFINADO', 'EVALUACIÓN DE CONOCIMIENTO', 1, 'despues', '2025-01-01', 1),
	(3, 'Examen 03', '', 2, 'antes', '2025-01-10', 1),
	(4, 'Examen 04', '', 2, 'despues', '2025-02-15', 1);

-- Volcando estructura para tabla app_capacitaciones.examenes_asignados
DROP TABLE IF EXISTS `examenes_asignados`;
CREATE TABLE IF NOT EXISTS `examenes_asignados` (
  `id_asignacion` int NOT NULL AUTO_INCREMENT,
  `id_estudiante` int DEFAULT NULL,
  `id_examen` int DEFAULT NULL,
  `tipo_examen` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fecha_asignacion` date DEFAULT NULL,
  PRIMARY KEY (`id_asignacion`),
  KEY `id_estudiante` (`id_estudiante`),
  KEY `id_examen` (`id_examen`),
  CONSTRAINT `examenes_asignados_ibfk_1` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`),
  CONSTRAINT `examenes_asignados_ibfk_2` FOREIGN KEY (`id_examen`) REFERENCES `examenes` (`id_examen`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.examenes_asignados: ~8 rows (aproximadamente)
DELETE FROM `examenes_asignados`;
INSERT INTO `examenes_asignados` (`id_asignacion`, `id_estudiante`, `id_examen`, `tipo_examen`, `fecha_asignacion`) VALUES
	(1, 1129580584, 1, 'antes', '2024-03-30'),
	(2, 1129580584, 2, 'despues', '2024-04-03'),
	(3, 2, 1, NULL, '2024-04-09'),
	(4, 2, 4, NULL, '2024-04-09'),
	(5, 2, 2, NULL, '2024-04-09'),
	(6, 1, 3, NULL, '2024-04-09'),
	(7, 1129580584, 3, NULL, '2024-04-09'),
	(8, 2, 3, NULL, '2024-04-09');

-- Volcando estructura para tabla app_capacitaciones.menus
DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
  `id_menu` int NOT NULL AUTO_INCREMENT,
  `nombre_menu` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `url_menu` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `nivel` int NOT NULL,
  `padre` int NOT NULL,
  `orden` int DEFAULT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.menus: ~14 rows (aproximadamente)
DELETE FROM `menus`;
INSERT INTO `menus` (`id_menu`, `nombre_menu`, `url_menu`, `nivel`, `padre`, `orden`) VALUES
	(1, 'Dashboard', 'x', 0, 0, NULL),
	(2, 'Gestión de usuarios', 'x', 0, 0, NULL),
	(3, 'Examenes', 'x', 1, 0, 5),
	(4, 'Examenes pendientes', 'examen-pending.php', 2, 3, 3),
	(5, 'Modulos', 'x', 1, 0, 4),
	(6, 'Usuarios', 'x', 1, 0, 1),
	(7, 'Empresas', 'x', 1, 0, 2),
	(8, 'Asignar examenes', 'examen-new.php', 2, 3, 2),
	(9, 'Listar examenes', 'examen-list.php', 2, 3, 1),
	(10, 'Listar modulo', 'modulo-list.php', 2, 5, 1),
	(11, 'Estudiantes', 'X', 1, 0, 3),
	(12, 'Listar usuarios', 'usuarios-list.php', 2, 6, 1),
	(13, 'Listar estudiantes', 'estudiantes-list.php', 2, 11, 1),
	(14, 'Listar Empresas', 'empresa-list.php', 2, 7, 1);

-- Volcando estructura para tabla app_capacitaciones.modulos
DROP TABLE IF EXISTS `modulos`;
CREATE TABLE IF NOT EXISTS `modulos` (
  `id_modulo` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fecha_vigencia` date DEFAULT NULL,
  PRIMARY KEY (`id_modulo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.modulos: ~2 rows (aproximadamente)
DELETE FROM `modulos`;
INSERT INTO `modulos` (`id_modulo`, `nombre`, `fecha_vigencia`) VALUES
	(1, 'MODULO UAS', '2025-01-01'),
	(2, 'Módulo 2', '2024-02-01');

-- Volcando estructura para tabla app_capacitaciones.perfiles
DROP TABLE IF EXISTS `perfiles`;
CREATE TABLE IF NOT EXISTS `perfiles` (
  `id_perfil` int NOT NULL AUTO_INCREMENT,
  `nombre_perfil` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.perfiles: ~4 rows (aproximadamente)
DELETE FROM `perfiles`;
INSERT INTO `perfiles` (`id_perfil`, `nombre_perfil`) VALUES
	(1, 'ADMINISTRADOR'),
	(2, 'ESTUDIANTE'),
	(3, 'EVALUADOR01'),
	(4, 'EVALUADOR02');

-- Volcando estructura para tabla app_capacitaciones.permisos
DROP TABLE IF EXISTS `permisos`;
CREATE TABLE IF NOT EXISTS `permisos` (
  `id_permiso` int NOT NULL AUTO_INCREMENT,
  `nombre_permiso` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `id_menu` int DEFAULT NULL,
  PRIMARY KEY (`id_permiso`),
  KEY `id_menu` (`id_menu`),
  CONSTRAINT `permisos_ibfk_1` FOREIGN KEY (`id_menu`) REFERENCES `menus` (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.permisos: ~14 rows (aproximadamente)
DELETE FROM `permisos`;
INSERT INTO `permisos` (`id_permiso`, `nombre_permiso`, `id_menu`) VALUES
	(1, 'ver_dashboard', 1),
	(2, 'editar_usuarios', 2),
	(3, 'Examenes', 3),
	(4, 'Examenes pendientes', 4),
	(5, 'Listar Examenes', 9),
	(6, 'Listar modulo', 10),
	(13, 'Modulos', 5),
	(14, 'Usuarios', 6),
	(15, 'Empresa', 7),
	(16, 'Asignar examenes', 8),
	(17, 'Listar usuarios', 12),
	(18, 'Listar empresa', 14),
	(19, 'Listar estudiantes', 13),
	(20, 'Estudiantes', 11);

-- Volcando estructura para tabla app_capacitaciones.preguntas
DROP TABLE IF EXISTS `preguntas`;
CREATE TABLE IF NOT EXISTS `preguntas` (
  `id_pregunta` int NOT NULL AUTO_INCREMENT,
  `id_examen` int DEFAULT NULL,
  `texto_pregunta` text COLLATE utf8mb4_general_ci,
  `imagen_url` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_pregunta`),
  KEY `id_examen` (`id_examen`),
  CONSTRAINT `preguntas_ibfk_1` FOREIGN KEY (`id_examen`) REFERENCES `examenes` (`id_examen`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.preguntas: ~10 rows (aproximadamente)
DELETE FROM `preguntas`;
INSERT INTO `preguntas` (`id_pregunta`, `id_examen`, `texto_pregunta`, `imagen_url`) VALUES
	(1, 1, '¿Cuál de los siguientes factores NO es un criterio que establece la presencia de\nun espacio confinado?', NULL),
	(2, 1, '¿Cuáles son los métodos para identificar la presencia de atmósferas tóxicas o\nexplosivas dentro de un espacio confinado?', NULL),
	(3, 1, '¿Un espacio confinado con una pequeña abertura y atmosfera toxica, está\ncategorizado como tipo __ y grado __?', NULL),
	(4, 1, '¿Qué peligro NO corresponde a una situación inminente que comprometa la vida o\nla salud de las personas en un espacio confinado clasificado como grado A?', NULL),
	(5, 1, 'En Colombia, ¿Cuáles son reconocidas como medidas preventivas para el trabajo\nen espacios confinados?', NULL),
	(6, 1, '¿Cuál de los siguientes elementos forma parte de las medidas de protección para\ntrabajos en espacios confinados?', NULL),
	(7, 1, '¿Cuál de los siguientes sistemas representa una medida de protección para\ntrabajos en espacios confinados?', NULL),
	(8, 1, '¿Cuál de los siguientes elementos es el más adecuado para bloquear una energía\npeligrosa de una línea presurizada?', NULL),
	(9, 1, 'El control de acceso en los espacios confinados pertenece a:', NULL),
	(10, 1, '¿Qué elemento de los siguientes es una medida preventiva diseñada para\nsalvaguardar al rescatista durante una operación de rescate?', NULL);

-- Volcando estructura para tabla app_capacitaciones.respuestas
DROP TABLE IF EXISTS `respuestas`;
CREATE TABLE IF NOT EXISTS `respuestas` (
  `id_respuesta` int NOT NULL AUTO_INCREMENT,
  `id_pregunta` int DEFAULT NULL,
  `texto_respuesta` text COLLATE utf8mb4_general_ci,
  `correcta` tinyint(1) DEFAULT NULL,
  `imagen_url` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_respuesta`),
  KEY `id_pregunta` (`id_pregunta`),
  CONSTRAINT `respuestas_ibfk_1` FOREIGN KEY (`id_pregunta`) REFERENCES `preguntas` (`id_pregunta`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.respuestas: ~16 rows (aproximadamente)
DELETE FROM `respuestas`;
INSERT INTO `respuestas` (`id_respuesta`, `id_pregunta`, `texto_respuesta`, `correcta`, `imagen_url`) VALUES
	(1, 1, 'Que tengas accesos y salidas restringidas', 0, NULL),
	(2, 1, 'Que sea abierto en su parte superior', 1, NULL),
	(3, 1, 'Que no esté diseñado para la permanencia de una persona', 0, NULL),
	(4, 1, 'Que sea lo suficientemente grande para que un trabajador pueda entrar', 0, NULL),
	(5, 2, 'Utilizando equipos de respiración autónoma.', 0, NULL),
	(6, 2, 'Liberando un ave dentro del espacio.', 0, NULL),
	(7, 2, 'Realizando mediciones estratificadas.', 1, NULL),
	(8, 2, 'Todas las anteriores', 0, NULL),
	(9, 3, 'Tipo 1 Grado A', 0, NULL),
	(10, 3, 'Tipo 2 Grado A', 1, NULL),
	(11, 3, 'Grado 2 Tipo B', 0, NULL),
	(12, 3, 'Grado 2 Tipo C', 0, NULL),
	(13, 4, 'Falta de oxígeno.', 0, NULL),
	(14, 4, 'Presencia de gases tóxicos.', 0, NULL),
	(15, 4, 'Riesgo de incendio repentino.', 0, NULL),
	(16, 4, 'Peligros potenciales como lesiones y/o enfermedades.', 1, NULL);

-- Volcando estructura para tabla app_capacitaciones.respuestas_estudiantes
DROP TABLE IF EXISTS `respuestas_estudiantes`;
CREATE TABLE IF NOT EXISTS `respuestas_estudiantes` (
  `id_respuesta_estudiante` int NOT NULL AUTO_INCREMENT,
  `id_estudiante` int DEFAULT NULL,
  `id_examen` int DEFAULT NULL,
  `respuestas_correctas` int DEFAULT NULL,
  `respuestas_incorrectas` int DEFAULT NULL,
  `total_preguntas` int DEFAULT NULL,
  `porcentaje` float NOT NULL,
  `fecha_realizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_respuesta_estudiante`),
  KEY `id_estudiante` (`id_estudiante`),
  KEY `id_examen` (`id_examen`),
  CONSTRAINT `respuestas_estudiantes_ibfk_1` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`),
  CONSTRAINT `respuestas_estudiantes_ibfk_2` FOREIGN KEY (`id_examen`) REFERENCES `examenes` (`id_examen`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.respuestas_estudiantes: ~1 rows (aproximadamente)
DELETE FROM `respuestas_estudiantes`;
INSERT INTO `respuestas_estudiantes` (`id_respuesta_estudiante`, `id_estudiante`, `id_examen`, `respuestas_correctas`, `respuestas_incorrectas`, `total_preguntas`, `porcentaje`, `fecha_realizacion`) VALUES
	(8, 1129580584, 1, 3, 1, 4, 75, '2024-04-04 04:41:25');

-- Volcando estructura para tabla app_capacitaciones.usuarios
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `correo_usuario` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `contrasena_usuario` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `id_perfil` int DEFAULT NULL,
  `estudiante` int NOT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo_usuario` (`correo_usuario`),
  KEY `id_perfil` (`id_perfil`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_perfil`) REFERENCES `perfiles` (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.usuarios: ~2 rows (aproximadamente)
DELETE FROM `usuarios`;
INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `correo_usuario`, `contrasena_usuario`, `id_perfil`, `estudiante`) VALUES
	(1, '1129580584', 'abc@abc.com', '123456', 2, 1129580584),
	(3, 'administrador', 'abcd@abcd.com', '123456', 1, 0);

-- Volcando estructura para tabla app_capacitaciones.usuarios_permisos
DROP TABLE IF EXISTS `usuarios_permisos`;
CREATE TABLE IF NOT EXISTS `usuarios_permisos` (
  `id_usuario_permiso` int NOT NULL AUTO_INCREMENT,
  `id_perfil` int DEFAULT NULL,
  `id_permiso` int DEFAULT NULL,
  PRIMARY KEY (`id_usuario_permiso`),
  KEY `usuarios_permisos_ibfk_2` (`id_permiso`),
  CONSTRAINT `usuarios_permisos_ibfk_2` FOREIGN KEY (`id_permiso`) REFERENCES `permisos` (`id_permiso`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla app_capacitaciones.usuarios_permisos: ~14 rows (aproximadamente)
DELETE FROM `usuarios_permisos`;
INSERT INTO `usuarios_permisos` (`id_usuario_permiso`, `id_perfil`, `id_permiso`) VALUES
	(1, 2, 4),
	(2, 2, 3),
	(3, 1, 20),
	(4, 1, 18),
	(5, 1, 3),
	(6, 1, 4),
	(7, 1, 15),
	(8, 1, 13),
	(9, 1, 16),
	(10, 1, 5),
	(11, 1, 6),
	(12, 1, 19),
	(13, 1, 14),
	(14, 1, 17);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
